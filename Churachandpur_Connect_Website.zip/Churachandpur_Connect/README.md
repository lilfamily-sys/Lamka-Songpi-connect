# Churachandpur Connect — Local Services Directory

A responsive, searchable static website for essential services in Churachandpur, Manipur.

## Run locally
1. Extract the ZIP.
2. Open `index.html` in a modern browser.
3. Keep `index.html`, `styles.css`, `app.js`, and `data.json` in the same folder.

For local preview using Python, run `python -m http.server 8000` in this folder and open `http://localhost:8000`.

## Features
- Responsive mobile/desktop layout
- Search and category filters
- Emergency phone links
- Government, banking, healthcare, education, public utility and transport listings
- Official website links, clickable phone numbers and email links
- Dark mode
- Sources and verification disclaimer

## Important accuracy note
This is an independent directory, not an official government website. The data is based primarily on the Churachandpur district portal and other official websites available at the time of preparation (15 November 2026). Office hours are not published for many listings and are intentionally marked as unverified rather than guessed. Confirm numbers, hours, branch locations, services and availability directly before relying on them. Some institutions do not publish a direct website or phone number; in those cases the district directory is linked.

## Updating listings
Edit `data.json`. Each service is an object with `category`, `name`, `address`, optional `phone`, `email`, `hours`, `url`, `detail`, and `source`.

## Primary sources
- https://churachandpur.nic.in/
- https://churachandpur.nic.in/helpline/
- https://churachandpur.nic.in/public-utility-category/hospitals/
- https://churachandpur.nic.in/public-utility-category/banks/
- https://churachandpur.nic.in/public-utility-category/colleges/
- https://churachandpur.nic.in/directory/
- https://churachandpur.nic.in/services/
- https://churachandpur.nic.in/service/csc/
- https://manipurpolice.gov.in/police-control/
- https://churachandpurcollege.edu.in/
