const DATA_URL = "data.json";
const icons = {"Government":"⌂","Banking":"▤","Healthcare":"✚","Education":"▣","Public Utilities":"⌁","Transport":"↗","Utilities":"✳"};
let allServices = [], activeCategory = "All";
const $ = s => document.querySelector(s);
function esc(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function phoneLink(phone){return phone?`<a href="tel:${phone.replace(/[^\d+]/g,"")}">Call ${esc(phone)}</a>`:"";}
function renderEmergency(items){
  $("#emergencyGrid").innerHTML = items.map(x=>`<div class="emergency-item"><small>${esc(x.name)}</small><a href="tel:${x.phone.replace(/[^\d+]/g,"")}">${esc(x.phone)}</a><span>${esc(x.detail)}</span></div>`).join("");
}
function renderFilters(){
 const cats=["All",...new Set(allServices.map(x=>x.category))];
 $("#filters").innerHTML=cats.map(c=>`<button class="filter-btn ${c===activeCategory?"active":""}" data-cat="${esc(c)}">${c==="All"?"All services":`${icons[c]||"•"} ${esc(c)}`}</button>`).join("");
 $("#filters").querySelectorAll("button").forEach(b=>b.addEventListener("click",()=>{activeCategory=b.dataset.cat;renderFilters();renderCards();}));
}
function card(x){
 const web=x.url?`<a class="primary" href="${esc(x.url)}" target="_blank" rel="noopener">Official info ↗</a>`:"";
 const phone=x.phone?`<a href="tel:${x.phone.replace(/[^\d+]/g,"")}">Call office</a>`:"";
 const email=x.email?`<a href="mailto:${esc(x.email)}">Email</a>`:"";
 return `<article class="service-card"><div class="card-top"><span class="category-tag">${esc(x.category)}</span><span class="card-arrow">↗</span></div><h3>${esc(x.name)}</h3><p>${esc(x.detail||"")}</p><div class="card-meta"><div>⌖ ${esc(x.address||"Online")}</div>${x.hours?`<div>◷ ${esc(x.hours)}</div>`:""}${x.phone?`<div>☎ ${esc(x.phone)}</div>`:""}${x.email?`<div>✉ ${esc(x.email)}</div>`:""}</div><div class="card-actions">${web}${phone}${email}</div></article>`;
}
function renderCards(){
 const q=$("#searchInput").value.trim().toLowerCase();
 const found=allServices.filter(x=>(activeCategory==="All"||x.category===activeCategory)&&[x.name,x.category,x.address,x.detail,x.phone,x.email].join(" ").toLowerCase().includes(q));
 $("#directoryGrid").innerHTML=found.map(card).join("");
 $("#resultCount").textContent=found.length;
 $("#emptyState").hidden=found.length!==0;
}
function renderSources(sources){$("#sourceList").innerHTML=sources.map(s=>`<a href="${esc(s.url)}" target="_blank" rel="noopener">${esc(s.label)} ↗</a>`).join("");}
fetch(DATA_URL).then(r=>{if(!r.ok)throw Error("Could not load directory data");return r.json();}).then(d=>{
 allServices=d.services;renderEmergency(d.emergency);renderFilters();renderCards();renderSources(d.sources);
 document.title=d.meta.title+" — Local Services Directory";
}).catch(()=>{$("#directoryGrid").innerHTML="<p>Directory data could not be loaded. Please open this site from the extracted folder so data.json is available.</p>";});
$("#searchInput").addEventListener("input",renderCards);
$("#clearBtn").addEventListener("click",()=>{$("#searchInput").value="";activeCategory="All";renderFilters();renderCards();});
$("#themeToggle").addEventListener("click",()=>document.body.classList.toggle("dark"));
document.addEventListener("keydown",e=>{if(e.key==="/"&&!["INPUT","TEXTAREA"].includes(document.activeElement.tagName)){e.preventDefault();$("#searchInput").focus();}});
